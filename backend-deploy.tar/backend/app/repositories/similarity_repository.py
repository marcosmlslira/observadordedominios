"""Repository for similarity scan operations — candidate queries and match persistence."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import case, text
from sqlalchemy.orm import Session

from app.models.similarity_match import SimilarityMatch
from app.models.similarity_scan_cursor import SimilarityScanCursor
from app.models.similarity_scan_job import SimilarityScanJob

logger = logging.getLogger(__name__)

# Per-TLD query timeout (milliseconds).
# Large partitions need more time for GIN index scans.
# Each sub-query runs inside its own savepoint, so a timeout only skips
# that sub-query — the overall fetch still succeeds with partial results.
_TLD_QUERY_TIMEOUT_MS: dict[str, int] = {
    "com": 600_000,    # 10 min — ~170M rows
    "net": 300_000,    # 5 min
    "org": 300_000,    # 5 min
    "com.br": 180_000, # 3 min
    "info": 120_000,
    "br": 120_000,
}
_DEFAULT_QUERY_TIMEOUT_MS = 45_000  # 45 s for all other TLDs


class SimilarityRepository:
    """Handles candidate fetching from domain table and match CRUD."""

    def __init__(self, db: Session) -> None:
        self.db = db

    # ── Candidate Queries ──────────────────────────────────────

    def _exec_candidate_part(
        self,
        sql: str,
        params: dict,
        *,
        timeout_ms: int,
        part_name: str,
        tld: str,
    ) -> list:
        """Execute one candidate sub-query inside a savepoint.

        A PostgreSQL savepoint isolates the SET LOCAL statement_timeout so that
        a query cancellation does not abort the outer transaction.  On timeout,
        logs a warning and returns an empty list instead of raising.
        """
        try:
            sp = self.db.begin_nested()
            self.db.execute(text(f"SET LOCAL statement_timeout = '{timeout_ms}'"))
            rows = self.db.execute(text(sql), params).fetchall()
            sp.commit()
            return rows
        except Exception as exc:
            sp.rollback()
            exc_str = str(exc).lower()
            if "canceling statement" in exc_str or "statement timeout" in exc_str:
                logger.warning(
                    "Candidate query timed out (tld=%s part=%s timeout=%dms) — skipping this sub-query",
                    tld, part_name, timeout_ms,
                )
                return []
            raise

    def fetch_candidates(
        self,
        brand_label: str,
        tld: str,
        typo_candidates: list[str],
        *,
        watermark_at: datetime | None = None,
        include_subdomains: bool = False,
        limit: int = 5000,
    ) -> list[dict]:
        """Candidate query: trigram + substring + typo exact match.

        Each sub-query runs in its own savepoint so a timeout on one part
        (e.g. trigram on .com) does not abort the others.  Results are
        deduplicated by domain name, keeping the row with the highest
        sim_trigram score.

        Returns dicts with: name, tld, label, first_seen_at, sim_trigram, edit_dist.
        """
        brand_like = f"%{brand_label}%"

        base_params: dict = {
            "brand_label": brand_label,
            "brand_like": brand_like,
            "tld": tld,
        }
        if watermark_at:
            base_params["watermark_at"] = watermark_at

        wm_filter = "AND first_seen_at > :watermark_at" if watermark_at else ""
        subdomain_filter = "" if include_subdomains else "AND label NOT LIKE '%.%'"

        # Dynamic threshold: stricter for short brands to avoid false positives
        # on large TLD partitions (170M+ rows for .com)
        blen = len(brand_label)
        if blen <= 5:
            sim_threshold = 0.55
        elif blen <= 8:
            sim_threshold = 0.45
        else:
            sim_threshold = 0.35

        timeout_ms = _TLD_QUERY_TIMEOUT_MS.get(tld, _DEFAULT_QUERY_TIMEOUT_MS)

        # Set similarity threshold for the entire transaction (no savepoint needed,
        # this is just a planner hint — no harm if it persists slightly longer).
        self.db.execute(
            text("SET LOCAL pg_trgm.similarity_threshold = :t"),
            {"t": sim_threshold},
        )

        # ── Part 1: Trigram similarity (GIN index via % operator) ──────────
        trigram_sql = f"""
            SELECT DISTINCT name, tld, label, first_seen_at,
                   similarity(label, :brand_label) AS sim_trigram,
                   levenshtein(label, :brand_label) AS edit_dist
            FROM domain
            WHERE tld = :tld
              AND label % :brand_label
              {subdomain_filter}
              {wm_filter}
            LIMIT :limit
        """
        trigram_rows = self._exec_candidate_part(
            trigram_sql, {**base_params, "limit": limit},
            timeout_ms=timeout_ms, part_name="trigram", tld=tld,
        )

        # ── Part 2: Substring / brand containment (LIKE, uses GIN index) ──
        substring_sql = f"""
            SELECT DISTINCT name, tld, label, first_seen_at,
                   similarity(label, :brand_label) AS sim_trigram,
                   levenshtein(label, :brand_label) AS edit_dist
            FROM domain
            WHERE tld = :tld
              AND label LIKE :brand_like
              {subdomain_filter}
              {wm_filter}
            LIMIT :limit
        """
        substring_rows = self._exec_candidate_part(
            substring_sql, {**base_params, "limit": limit},
            timeout_ms=timeout_ms, part_name="substring", tld=tld,
        )

        # ── Part 3: Typo exact match (equality scan, always fast) ──────────
        typo_rows: list = []
        if typo_candidates:
            typo_sql = f"""
                SELECT DISTINCT name, tld, label, first_seen_at,
                       similarity(label, :brand_label) AS sim_trigram,
                       levenshtein(label, :brand_label) AS edit_dist
                FROM domain
                WHERE tld = :tld
                  AND label = ANY(:typo_candidates)
                  {subdomain_filter}
                  {wm_filter}
                LIMIT :limit
            """
            typo_rows = self._exec_candidate_part(
                typo_sql,
                {**base_params, "typo_candidates": typo_candidates, "limit": limit},
                timeout_ms=timeout_ms, part_name="typo", tld=tld,
            )

        # ── Merge: deduplicate by name, keep row with highest sim_trigram ──
        best_by_name: dict[str, object] = {}
        for r in (*trigram_rows, *substring_rows, *typo_rows):
            existing = best_by_name.get(r.name)
            if existing is None or float(r.sim_trigram) > float(existing.sim_trigram):
                best_by_name[r.name] = r

        sorted_rows = sorted(
            best_by_name.values(),
            key=lambda r: float(r.sim_trigram),
            reverse=True,
        )[:limit]

        return [
            {
                "name": r.name,
                "tld": r.tld,
                "label": r.label,
                "first_seen_at": r.first_seen_at,
                "last_seen_at": getattr(r, "last_seen_at", None),
                "sim_trigram": float(r.sim_trigram),
                "edit_dist": int(r.edit_dist),
            }
            for r in sorted_rows
        ]

    def fetch_candidates_exact(
        self,
        candidate_labels: list[str],
        brand_label: str,
        tld: str,
        *,
        watermark_at: datetime | None = None,
        limit: int = 2000,
    ) -> list[dict]:
        """Exact-label lookup for typo/homograph seeds via btree equality scan.

        Processes candidates in chunks of 1000 to stay within pg parameter limits.
        Returns dicts with: name, tld, label, first_seen_at, sim_trigram, edit_dist.
        """
        if not candidate_labels:
            return []

        wm_filter = "AND first_seen_at > :watermark_at" if watermark_at else ""
        timeout_ms = _TLD_QUERY_TIMEOUT_MS.get(tld, _DEFAULT_QUERY_TIMEOUT_MS)

        sql = f"""
            SELECT DISTINCT name, tld, label, first_seen_at,
                   similarity(label, :brand_label) AS sim_trigram,
                   levenshtein(label, :brand_label) AS edit_dist
            FROM domain
            WHERE tld = :tld
              AND label = ANY(:candidate_labels)
              AND label NOT LIKE '%%.%%'
              {wm_filter}
            LIMIT :limit
        """
        all_rows: list = []
        for i in range(0, len(candidate_labels), 1000):
            chunk = candidate_labels[i : i + 1000]
            params: dict = {
                "brand_label": brand_label,
                "tld": tld,
                "candidate_labels": chunk,
                "limit": limit,
            }
            if watermark_at:
                params["watermark_at"] = watermark_at
            rows = self._exec_candidate_part(
                sql, params,
                timeout_ms=timeout_ms,
                part_name=f"exact_chunk_{i // 1000}",
                tld=tld,
            )
            all_rows.extend(rows)

        best_by_name: dict[str, object] = {}
        for r in all_rows:
            existing = best_by_name.get(r.name)
            if existing is None or float(r.sim_trigram) > float(existing.sim_trigram):
                best_by_name[r.name] = r

        return [
            {
                "name": r.name,
                "tld": r.tld,
                "label": r.label,
                "first_seen_at": r.first_seen_at,
                "last_seen_at": getattr(r, "last_seen_at", None),
                "sim_trigram": float(r.sim_trigram),
                "edit_dist": int(r.edit_dist),
            }
            for r in sorted(best_by_name.values(), key=lambda r: float(r.sim_trigram), reverse=True)[:limit]
        ]

    def fetch_candidates_punycode(
        self,
        brand_label: str,
        tld: str,
        *,
        watermark_at: datetime | None = None,
        limit: int = 1200,
    ) -> list[dict]:
        """Fetch Punycode (IDN homograph) domains for a TLD.

        Uses LIKE 'xn--%' filter to pull all IDN domains, then scores them
        against the brand label for downstream filtering.
        Returns dicts with: name, tld, label, first_seen_at, sim_trigram, edit_dist.
        """
        wm_filter = "AND first_seen_at > :watermark_at" if watermark_at else ""
        timeout_ms = _TLD_QUERY_TIMEOUT_MS.get(tld, _DEFAULT_QUERY_TIMEOUT_MS)

        sql = f"""
            SELECT DISTINCT name, tld, label, first_seen_at,
                   similarity(label, :brand_label) AS sim_trigram,
                   levenshtein(label, :brand_label) AS edit_dist
            FROM domain
            WHERE tld = :tld
              AND label LIKE 'xn--%%'
              AND label NOT LIKE '%%.%%'
              {wm_filter}
            ORDER BY levenshtein(label, :brand_label) ASC, first_seen_at DESC
            LIMIT :limit
        """
        params: dict = {"brand_label": brand_label, "tld": tld, "limit": limit}
        if watermark_at:
            params["watermark_at"] = watermark_at

        rows = self._exec_candidate_part(
            sql, params,
            timeout_ms=timeout_ms,
            part_name="punycode",
            tld=tld,
        )

        return [
            {
                "name": r.name,
                "tld": r.tld,
                "label": r.label,
                "first_seen_at": r.first_seen_at,
                "last_seen_at": getattr(r, "last_seen_at", None),
                "sim_trigram": float(r.sim_trigram),
                "edit_dist": int(r.edit_dist),
            }
            for r in rows
        ]

    def search_candidates(
        self,
        query_label: str,
        typo_candidates: list[str],
        *,
        tld_allowlist: list[str] | None = None,
        include_subdomains: bool = False,
        use_fuzzy: bool = True,
        use_typo: bool = True,
        limit: int = 500,
        offset: int = 0,
    ) -> list[dict]:
        """Search candidates across TLDs for the synchronous similarity API."""
        params: dict = {
            "brand_label": query_label,
            "brand_like": f"%{query_label}%",
            "limit": limit,
            "offset": offset,
        }

        base_filters: list[str] = []
        if tld_allowlist:
            params["tld_allowlist"] = tld_allowlist
            base_filters.append("tld = ANY(:tld_allowlist)")
        if not include_subdomains:
            base_filters.append("label NOT LIKE '%.%'")
        base_where = " AND ".join(base_filters) if base_filters else "TRUE"

        sim_threshold = 0.5 if len(query_label) <= 5 else 0.3
        self.db.execute(
            text("SET LOCAL pg_trgm.similarity_threshold = :t"),
            {"t": sim_threshold},
        )

        candidate_queries: list[str] = []
        if use_fuzzy:
            candidate_queries.extend(
                [
                    f"""
                    SELECT DISTINCT name, tld, label, first_seen_at, last_seen_at,
                           similarity(label, :brand_label) AS sim_trigram,
                           levenshtein(label, :brand_label) AS edit_dist
                    FROM domain
                    WHERE {base_where}
                      AND label % :brand_label
                    """,
                    f"""
                    SELECT DISTINCT name, tld, label, first_seen_at, last_seen_at,
                           similarity(label, :brand_label) AS sim_trigram,
                           levenshtein(label, :brand_label) AS edit_dist
                    FROM domain
                    WHERE {base_where}
                      AND label LIKE :brand_like
                    """,
                ]
            )

        if use_typo and typo_candidates:
            params["typo_candidates"] = typo_candidates
            candidate_queries.append(
                f"""
                SELECT DISTINCT name, tld, label, first_seen_at, last_seen_at,
                       similarity(label, :brand_label) AS sim_trigram,
                       levenshtein(label, :brand_label) AS edit_dist
                FROM domain
                WHERE {base_where}
                  AND label = ANY(:typo_candidates)
                """
            )

        if not candidate_queries:
            return []

        sql = f"""
            WITH candidates AS (
                {" UNION ".join(candidate_queries)}
            )
            SELECT * FROM candidates
            ORDER BY sim_trigram DESC, last_seen_at DESC, name ASC
            OFFSET :offset
            LIMIT :limit
        """

        rows = self.db.execute(text(sql), params).fetchall()
        return [
            {
                "name": r.name,
                "tld": r.tld,
                "label": r.label,
                "first_seen_at": r.first_seen_at,
                "last_seen_at": r.last_seen_at,
                "sim_trigram": float(r.sim_trigram),
                "edit_dist": int(r.edit_dist),
            }
            for r in rows
        ]

    def search_punycode_candidates(
        self,
        query_label: str,
        *,
        tld_allowlist: list[str] | None = None,
        include_subdomains: bool = False,
        limit: int = 500,
    ) -> list[dict]:
        """Search across TLDs for punycode labels for synchronous Ring C."""
        params: dict = {
            "brand_label": query_label,
            "limit": limit,
        }
        filters: list[str] = ["label LIKE 'xn--%'"]
        if tld_allowlist:
            params["tld_allowlist"] = tld_allowlist
            filters.append("tld = ANY(:tld_allowlist)")
        if not include_subdomains:
            filters.append("label NOT LIKE '%.%'")
        where_clause = " AND ".join(filters)

        sql = f"""
            SELECT DISTINCT name, tld, label, first_seen_at, last_seen_at,
                   similarity(label, :brand_label) AS sim_trigram,
                   levenshtein(label, :brand_label) AS edit_dist
            FROM domain
            WHERE {where_clause}
            ORDER BY last_seen_at DESC NULLS LAST, first_seen_at DESC, name ASC
            LIMIT :limit
        """

        rows = self.db.execute(text(sql), params).fetchall()
        return [
            {
                "name": r.name,
                "tld": r.tld,
                "label": r.label,
                "first_seen_at": r.first_seen_at,
                "last_seen_at": r.last_seen_at,
                "sim_trigram": float(r.sim_trigram),
                "edit_dist": int(r.edit_dist),
            }
            for r in rows
        ]

    def delete_matches_for_brand_tld(
        self,
        brand_id: uuid.UUID,
        tld: str,
        domain_names: list[str],
    ) -> int:
        """Delete persisted matches for a brand/TLD and a known set of domains."""
        if not domain_names:
            return 0

        result = self.db.execute(
            text("""
                DELETE FROM similarity_match
                WHERE brand_id = :brand_id
                  AND tld = :tld
                  AND domain_name = ANY(:domain_names)
            """),
            {
                "brand_id": brand_id,
                "tld": tld,
                "domain_names": domain_names,
            },
        )
        return result.rowcount or 0

    def reconcile_matches_for_brand_tld(
        self,
        brand_id: uuid.UUID,
        tld: str,
        keep_domain_names: list[str],
    ) -> int:
        """Replace the persisted set for a brand/TLD with the provided domains."""
        if keep_domain_names:
            result = self.db.execute(
                text("""
                    DELETE FROM similarity_match
                    WHERE brand_id = :brand_id
                      AND tld = :tld
                      AND NOT (domain_name = ANY(:keep_domain_names))
                """),
                {
                    "brand_id": brand_id,
                    "tld": tld,
                    "keep_domain_names": keep_domain_names,
                },
            )
        else:
            result = self.db.execute(
                text("""
                    DELETE FROM similarity_match
                    WHERE brand_id = :brand_id
                      AND tld = :tld
                """),
                {
                    "brand_id": brand_id,
                    "tld": tld,
                },
            )
        return result.rowcount or 0

    def delete_subdomain_matches(
        self,
        brand_id: uuid.UUID,
        tld: str,
    ) -> int:
        """Drop stored subdomain/hostname matches from the alert stream."""
        result = self.db.execute(
            text("""
                DELETE FROM similarity_match
                WHERE brand_id = :brand_id
                  AND tld = :tld
                  AND label LIKE '%.%'
            """),
            {
                "brand_id": brand_id,
                "tld": tld,
            },
        )
        return result.rowcount or 0

    # ── Cursor Operations ──────────────────────────────────────

    def get_or_create_cursor(
        self, brand_id: uuid.UUID, tld: str,
    ) -> SimilarityScanCursor:
        cursor = self.db.get(SimilarityScanCursor, (brand_id, tld))
        if cursor:
            return cursor

        cursor = SimilarityScanCursor(
            brand_id=brand_id,
            tld=tld,
            scan_phase="initial",
            status="pending",
            domains_scanned=0,
            domains_matched=0,
            updated_at=datetime.now(timezone.utc),
        )
        self.db.add(cursor)
        self.db.flush()
        return cursor

    def start_scan(self, cursor: SimilarityScanCursor) -> None:
        now = datetime.now(timezone.utc)
        cursor.status = "running"
        cursor.started_at = now
        cursor.error_message = None
        cursor.updated_at = now
        self.db.flush()

    def finish_scan(
        self,
        cursor: SimilarityScanCursor,
        *,
        status: str,
        watermark_at: datetime | None = None,
        domains_scanned: int = 0,
        domains_matched: int = 0,
        error_message: str | None = None,
    ) -> None:
        now = datetime.now(timezone.utc)
        cursor.status = status
        cursor.finished_at = now
        cursor.updated_at = now
        cursor.error_message = error_message

        if status == "complete":
            cursor.domains_scanned += domains_scanned
            cursor.domains_matched += domains_matched
            if watermark_at:
                cursor.watermark_at = watermark_at
            # After initial scan completes, switch to delta mode
            if cursor.scan_phase == "initial":
                cursor.scan_phase = "delta"
        self.db.flush()

    # ── Manual Scan Job Queue ─────────────────────────────────

    def create_scan_job(
        self,
        *,
        brand_id: uuid.UUID,
        requested_tld: str | None,
        effective_tlds: list[str],
        force_full: bool,
        initiated_by: str | None,
    ) -> SimilarityScanJob:
        now = datetime.now(timezone.utc)
        job = SimilarityScanJob(
            id=uuid.uuid4(),
            brand_id=brand_id,
            requested_tld=requested_tld,
            effective_tlds=effective_tlds,
            tld_results={
                tld: {
                    "status": "queued",
                    "candidates": 0,
                    "matched": 0,
                    "removed": 0,
                    "ring_c_candidates": 0,
                    "ring_c_matches": 0,
                    "ring_c_limit": 0,
                    "error_message": None,
                    "started_at": None,
                    "finished_at": None,
                }
                for tld in effective_tlds
            },
            force_full=force_full,
            status="queued",
            initiated_by=initiated_by,
            queued_at=now,
            created_at=now,
            updated_at=now,
        )
        self.db.add(job)
        self.db.flush()
        return job

    def get_scan_job(self, job_id: uuid.UUID) -> SimilarityScanJob | None:
        return self.db.get(SimilarityScanJob, job_id)

    def get_active_scan_job_for_brand(self, brand_id: uuid.UUID) -> SimilarityScanJob | None:
        return (
            self.db.query(SimilarityScanJob)
            .filter(
                SimilarityScanJob.brand_id == brand_id,
                SimilarityScanJob.status.in_(("queued", "running")),
            )
            .order_by(SimilarityScanJob.queued_at.asc())
            .first()
        )

    def get_latest_scan_job_for_brand(self, brand_id: uuid.UUID) -> SimilarityScanJob | None:
        return (
            self.db.query(SimilarityScanJob)
            .filter(SimilarityScanJob.brand_id == brand_id)
            .order_by(SimilarityScanJob.created_at.desc())
            .first()
        )

    def claim_next_queued_scan_job(self) -> SimilarityScanJob | None:
        row = self.db.execute(
            text(
                """
                SELECT id
                FROM similarity_scan_job
                WHERE status = 'queued'
                ORDER BY queued_at ASC
                LIMIT 1
                FOR UPDATE SKIP LOCKED
                """
            )
        ).first()
        if not row:
            return None
        job = self.db.get(SimilarityScanJob, row.id)
        if not job:
            return None
        self.start_scan_job(job)
        return job

    def start_scan_job(self, job: SimilarityScanJob) -> None:
        now = datetime.now(timezone.utc)
        job.status = "running"
        job.started_at = now
        job.last_heartbeat_at = now
        job.last_error = None
        job.updated_at = now
        self.db.flush()

    def heartbeat_scan_job(self, job: SimilarityScanJob) -> None:
        now = datetime.now(timezone.utc)
        job.last_heartbeat_at = now
        job.updated_at = now
        self.db.flush()

    def update_scan_job_tld(
        self,
        job: SimilarityScanJob,
        *,
        tld: str,
        status: str,
        candidates: int = 0,
        matched: int = 0,
        removed: int = 0,
        error_message: str | None = None,
        started_at: datetime | None = None,
        finished_at: datetime | None = None,
        extra_metrics: dict | None = None,
    ) -> None:
        results = dict(job.tld_results or {})
        current = dict(results.get(tld) or {})
        current.update(
            {
                "status": status,
                "candidates": candidates,
                "matched": matched,
                "removed": removed,
                "error_message": error_message,
                "started_at": started_at.isoformat() if started_at else current.get("started_at"),
                "finished_at": finished_at.isoformat() if finished_at else current.get("finished_at"),
            }
        )
        if extra_metrics:
            current.update(extra_metrics)
        results[tld] = current
        job.tld_results = results
        job.status = self._derive_scan_job_status(results)
        job.last_error = error_message if status in {"failed", "timed_out"} else job.last_error
        job.updated_at = datetime.now(timezone.utc)
        if job.status in {"completed", "partial", "failed", "timed_out"}:
            job.finished_at = datetime.now(timezone.utc)
        self.db.flush()

    def finalize_scan_job(self, job: SimilarityScanJob) -> None:
        job.status = self._derive_scan_job_status(job.tld_results or {})
        job.finished_at = datetime.now(timezone.utc)
        job.updated_at = datetime.now(timezone.utc)
        self.db.flush()

    @staticmethod
    def _derive_scan_job_status(results: dict) -> str:
        states = {str((payload or {}).get("status") or "queued") for payload in results.values()}
        # Treat timed_out as equivalent to failed for job-level status derivation
        normalized = {("failed" if s == "timed_out" else s) for s in states}
        if not normalized:
            return "failed"
        if normalized <= {"completed"}:
            return "completed"
        if normalized <= {"failed"}:
            return "failed"
        if "running" in normalized:
            return "running"
        if "queued" in normalized and normalized == {"queued"}:
            return "queued"
        if "failed" in normalized and "completed" in normalized:
            return "partial"
        if "failed" in normalized and "queued" in normalized:
            return "running"
        if "completed" in normalized and "queued" in normalized:
            return "running"
        return "partial"

    # ── Match Operations ───────────────────────────────────────

    def upsert_matches(self, matches: list[dict]) -> int:
        """Bulk upsert similarity matches. Returns count upserted."""
        if not matches:
            return 0

        BATCH_SIZE = 500
        insert_fields = [
            "brand_id",
            "domain_name",
            "tld",
            "label",
            "score_final",
            "score_trigram",
            "score_levenshtein",
            "score_brand_hit",
            "score_keyword",
            "score_homograph",
            "reasons",
            "risk_level",
            "actionability_score",
            "attention_bucket",
            "attention_reasons",
            "recommended_action",
            "enrichment_status",
            "enrichment_summary",
            "last_enriched_at",
            "ownership_classification",
            "self_owned",
            "disposition",
            "confidence",
            "delivery_risk",
            "llm_assessment",
            "first_detected_at",
            "domain_first_seen",
            "matched_channel",
            "matched_seed_id",
            "matched_seed_value",
            "matched_seed_type",
            "matched_rule",
            "source_stream",
        ]
        for i in range(0, len(matches), BATCH_SIZE):
            batch = matches[i : i + BATCH_SIZE]

            # Build VALUES placeholders with numbered suffixes
            values_clauses = []
            params: dict = {}
            for idx, m in enumerate(batch):
                suffix = f"_{idx}"
                values_clauses.append(
                    f"(gen_random_uuid(), :brand_id{suffix}, :domain_name{suffix}, "
                    f":tld{suffix}, :label{suffix}, :score_final{suffix}, "
                    f":score_trigram{suffix}, :score_levenshtein{suffix}, "
                    f":score_brand_hit{suffix}, :score_keyword{suffix}, "
                    f":score_homograph{suffix}, :reasons{suffix}, "
                    f":risk_level{suffix}, :actionability_score{suffix}, "
                    f":attention_bucket{suffix}, :attention_reasons{suffix}, "
                    f":recommended_action{suffix}, :enrichment_status{suffix}, "
                    f":enrichment_summary{suffix}, :last_enriched_at{suffix}, "
                    f":ownership_classification{suffix}, :self_owned{suffix}, "
                    f":disposition{suffix}, :confidence{suffix}, :delivery_risk{suffix}, "
                    f":llm_assessment{suffix}, "
                    f":first_detected_at{suffix}, :domain_first_seen{suffix}, "
                    f"'new', :matched_channel{suffix}, "
                    f":matched_seed_id{suffix}, :matched_seed_value{suffix}, "
                    f":matched_seed_type{suffix}, :matched_rule{suffix}, "
                    f":source_stream{suffix})"
                )
                for key in insert_fields:
                    params[f"{key}{suffix}"] = m.get(key)

            sql = f"""
                INSERT INTO similarity_match (
                    id, brand_id, domain_name, tld, label,
                    score_final, score_trigram, score_levenshtein,
                    score_brand_hit, score_keyword, score_homograph,
                    reasons, risk_level, actionability_score, attention_bucket,
                    attention_reasons, recommended_action, enrichment_status,
                    enrichment_summary, last_enriched_at, ownership_classification,
                    self_owned, disposition, confidence, delivery_risk, llm_assessment,
                    first_detected_at, domain_first_seen, status, matched_channel, matched_seed_id,
                    matched_seed_value, matched_seed_type, matched_rule, source_stream
                ) VALUES {", ".join(values_clauses)}
                ON CONFLICT (brand_id, domain_name) DO UPDATE SET
                    score_final = EXCLUDED.score_final,
                    score_trigram = EXCLUDED.score_trigram,
                    score_levenshtein = EXCLUDED.score_levenshtein,
                    score_brand_hit = EXCLUDED.score_brand_hit,
                    score_keyword = EXCLUDED.score_keyword,
                    score_homograph = EXCLUDED.score_homograph,
                    reasons = EXCLUDED.reasons,
                    risk_level = EXCLUDED.risk_level,
                    actionability_score = EXCLUDED.actionability_score,
                    attention_bucket = CASE
                        WHEN similarity_match.status IN ('dismissed', 'confirmed_threat')
                        THEN similarity_match.attention_bucket
                        ELSE EXCLUDED.attention_bucket
                    END,
                    attention_reasons = CASE
                        WHEN similarity_match.status IN ('dismissed', 'confirmed_threat')
                        THEN similarity_match.attention_reasons
                        ELSE EXCLUDED.attention_reasons
                    END,
                    recommended_action = CASE
                        WHEN similarity_match.status IN ('dismissed', 'confirmed_threat')
                        THEN similarity_match.recommended_action
                        ELSE EXCLUDED.recommended_action
                    END,
                    disposition = CASE
                        WHEN similarity_match.status IN ('dismissed', 'confirmed_threat')
                        THEN similarity_match.disposition
                        ELSE EXCLUDED.disposition
                    END,
                    enrichment_status = EXCLUDED.enrichment_status,
                    enrichment_summary = EXCLUDED.enrichment_summary,
                    last_enriched_at = EXCLUDED.last_enriched_at,
                    ownership_classification = EXCLUDED.ownership_classification,
                    self_owned = EXCLUDED.self_owned,
                    confidence = EXCLUDED.confidence,
                    delivery_risk = EXCLUDED.delivery_risk,
                    llm_assessment = EXCLUDED.llm_assessment,
                    matched_channel = EXCLUDED.matched_channel,
                    matched_seed_id = EXCLUDED.matched_seed_id,
                    matched_seed_value = EXCLUDED.matched_seed_value,
                    matched_seed_type = EXCLUDED.matched_seed_type,
                    matched_rule = EXCLUDED.matched_rule,
                    source_stream = EXCLUDED.source_stream
            """
            self.db.execute(text(sql), params)

        return len(matches)

    def list_matches(
        self,
        brand_id: uuid.UUID,
        *,
        status: str | None = None,
        risk_level: str | None = None,
        attention_bucket: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[SimilarityMatch]:
        q = self.db.query(SimilarityMatch).filter(
            SimilarityMatch.brand_id == brand_id,
        )
        if status:
            q = q.filter(SimilarityMatch.status == status)
        if risk_level:
            q = q.filter(SimilarityMatch.risk_level == risk_level)
        if attention_bucket:
            q = q.filter(SimilarityMatch.attention_bucket == attention_bucket)
        bucket_priority = case(
            (SimilarityMatch.attention_bucket == "immediate_attention", 0),
            (SimilarityMatch.attention_bucket == "defensive_gap", 1),
            else_=2,
        )
        return (
            q.order_by(
                bucket_priority.asc(),
                SimilarityMatch.actionability_score.desc(),
                SimilarityMatch.score_final.desc(),
            )
            .offset(offset)
            .limit(limit)
            .all()
        )

    def get_match(self, match_id: uuid.UUID) -> SimilarityMatch | None:
        return self.db.get(SimilarityMatch, match_id)

    def update_match_status(
        self,
        match: SimilarityMatch,
        *,
        status: str,
        reviewed_by: uuid.UUID | None = None,
        notes: str | None = None,
    ) -> SimilarityMatch:
        match.status = status
        if reviewed_by:
            match.reviewed_by = reviewed_by
            match.reviewed_at = datetime.now(timezone.utc)
        if notes is not None:
            match.notes = notes
        self.db.flush()
        return match

    def mark_match_owned(
        self,
        match: SimilarityMatch,
        *,
        add_to_profile: bool = False,
    ) -> SimilarityMatch:
        """Mark a match as confirmed company-owned (self_owned) and dismiss it.

        If ``add_to_profile`` is True the domain is appended to the brand's
        ``trusted_registrants.confirmed_domains`` list so that future enrichment
        auto-classifies it without requiring an analyst action.
        Caller must commit.
        """
        from sqlalchemy import text as sa_text

        match.self_owned = True
        match.ownership_classification = "confirmed_owned"
        match.auto_disposition = "self_owned"
        match.status = "dismissed"
        match.reviewed_at = datetime.now(timezone.utc)
        self.db.flush()

        if add_to_profile:
            self.db.execute(
                sa_text(
                    """
                    UPDATE monitored_brand
                    SET trusted_registrants = jsonb_set(
                        COALESCE(trusted_registrants, '{}'::jsonb),
                        '{confirmed_domains}',
                        COALESCE(trusted_registrants->'confirmed_domains', '[]'::jsonb)
                            || to_jsonb(:domain::text),
                        true
                    )
                    WHERE id = :brand_id
                    """
                ),
                {"domain": match.domain_name, "brand_id": str(match.brand_id)},
            )
            self.db.flush()

        return match

    def count_matches(
        self,
        brand_id: uuid.UUID,
        status: str | None = None,
        risk_level: str | None = None,
        attention_bucket: str | None = None,
    ) -> int:
        q = self.db.query(SimilarityMatch).filter(
            SimilarityMatch.brand_id == brand_id,
        )
        if status:
            q = q.filter(SimilarityMatch.status == status)
        if risk_level:
            q = q.filter(SimilarityMatch.risk_level == risk_level)
        if attention_bucket:
            q = q.filter(SimilarityMatch.attention_bucket == attention_bucket)
        return q.count()

    def get_discovery_trends(self, *, days: int = 30) -> dict:
        """Daily match discovery counts for the last N days, split by risk level and bucket."""
        daily = self.db.execute(text("""
            SELECT
                DATE(first_detected_at AT TIME ZONE 'UTC')        AS day,
                COUNT(*)                                           AS total,
                COUNT(*) FILTER (WHERE risk_level = 'critical')   AS critical,
                COUNT(*) FILTER (WHERE risk_level = 'high')       AS high,
                COUNT(*) FILTER (WHERE risk_level IN ('medium','low')) AS lower,
                COUNT(*) FILTER (WHERE attention_bucket = 'immediate_attention') AS immediate,
                COUNT(*) FILTER (WHERE disposition = 'likely_phishing')          AS phishing,
                COUNT(*) FILTER (WHERE disposition = 'mail_spoofing_risk')       AS mail_risk
            FROM similarity_match
            WHERE first_detected_at >= NOW() - (:days || ' days')::INTERVAL
            GROUP BY 1
            ORDER BY 1
        """), {"days": days}).fetchall()

        top_rising = self.db.execute(text("""
            SELECT
                sm.domain_name,
                mb.brand_name,
                sm.attention_bucket,
                sm.disposition,
                sm.actionability_score,
                sm.risk_level,
                sm.first_detected_at
            FROM similarity_match sm
            JOIN monitored_brand mb ON mb.id = sm.brand_id
            WHERE sm.first_detected_at >= NOW() - (:days || ' days')::INTERVAL
              AND sm.attention_bucket = 'immediate_attention'
              AND sm.status = 'new'
            ORDER BY sm.actionability_score DESC, sm.first_detected_at DESC
            LIMIT 20
        """), {"days": days}).fetchall()

        return {
            "window_days": days,
            "daily": [dict(r._mapping) for r in daily],
            "top_rising_immediate": [dict(r._mapping) for r in top_rising],
        }

    def get_operational_metrics(self) -> dict:
        """Aggregate operational health metrics across all brands in one query."""
        row = self.db.execute(text("""
            SELECT
                COUNT(*)                                                          AS total_matches,
                COUNT(*) FILTER (WHERE attention_bucket = 'immediate_attention')  AS immediate_attention,
                COUNT(*) FILTER (WHERE attention_bucket = 'defensive_gap')        AS defensive_gap,
                COUNT(*) FILTER (WHERE attention_bucket = 'watchlist')            AS watchlist,
                COUNT(*) FILTER (WHERE status = 'new')                            AS status_new,
                COUNT(*) FILTER (WHERE status = 'reviewing')                      AS status_reviewing,
                COUNT(*) FILTER (WHERE status = 'dismissed')                      AS status_dismissed,
                COUNT(*) FILTER (WHERE status = 'confirmed_threat')               AS status_confirmed,
                COUNT(*) FILTER (WHERE risk_level = 'critical')                   AS risk_critical,
                COUNT(*) FILTER (WHERE risk_level = 'high')                       AS risk_high,
                COUNT(*) FILTER (WHERE disposition = 'likely_phishing')           AS disposition_phishing,
                COUNT(*) FILTER (WHERE disposition = 'mail_spoofing_risk')        AS disposition_mail_risk,
                COUNT(*) FILTER (WHERE disposition = 'defensive_gap')             AS disposition_defensive,
                COUNT(*) FILTER (WHERE disposition = 'live_but_unknown')          AS disposition_live_unknown,
                COUNT(*) FILTER (WHERE disposition = 'inconclusive')              AS disposition_inconclusive,
                COUNT(*) FILTER (WHERE enrichment_status = 'completed')           AS enriched_count,
                COUNT(*) FILTER (WHERE first_detected_at >= NOW() - INTERVAL '24 hours') AS new_last_24h,
                COUNT(*) FILTER (WHERE first_detected_at >= NOW() - INTERVAL '7 days')   AS new_last_7d,
                MAX(first_detected_at)                                            AS latest_detection_at
            FROM similarity_match
        """)).fetchone()

        buckets = self.db.execute(text("""
            SELECT
                mb.brand_name,
                mb.brand_label,
                COUNT(sm.id)                                                           AS total,
                COUNT(sm.id) FILTER (WHERE sm.attention_bucket = 'immediate_attention') AS immediate,
                MAX(sm.first_detected_at)                                              AS last_match_at,
                MAX(sm.actionability_score)                                            AS top_score
            FROM monitored_brand mb
            LEFT JOIN similarity_match sm ON sm.brand_id = mb.id
            WHERE mb.is_active = true
            GROUP BY mb.id, mb.brand_name, mb.brand_label
            ORDER BY immediate DESC, total DESC
        """)).fetchall()

        last_job = self.db.execute(text("""
            SELECT status, created_at, finished_at
            FROM similarity_scan_job ssj
            ORDER BY created_at DESC
            LIMIT 1
        """)).fetchone()

        return {
            "totals": dict(row._mapping) if row else {},
            "by_brand": [dict(b._mapping) for b in buckets],
            "last_scan_job": dict(last_job._mapping) if last_job else None,
        }

    def get_new_immediate_matches_since(
        self,
        brand_id: uuid.UUID,
        since: datetime,
    ) -> list[dict]:
        """Return immediate_attention matches first detected after *since* for a brand.

        Used by the webhook dispatcher to find matches discovered in the current scan cycle.
        """
        rows = self.db.execute(
            text("""
                SELECT
                    domain_name, risk_level, disposition, attention_bucket,
                    actionability_score, recommended_action, first_detected_at
                FROM similarity_match
                WHERE brand_id = :brand_id
                  AND attention_bucket = 'immediate_attention'
                  AND status = 'new'
                  AND first_detected_at >= :since
                ORDER BY actionability_score DESC, first_detected_at DESC
                LIMIT 50
            """),
            {"brand_id": brand_id, "since": since},
        ).fetchall()
        return [dict(r._mapping) for r in rows]

    def compute_enrichment_budget_rank(
        self,
        brand_id: "UUID",
        *,
        limit: int = 50,
    ) -> int:
        """Rank matches for enrichment priority and store as enrichment_budget_rank.

        ALL immediate_attention matches are always ranked (no cap).
        Remaining budget slots (up to `limit`) are filled with lower-priority matches.

        Priority tiers for lower-priority fill:
          1 — new today
          2 — defensive_gap
          3 — watchlist with score_final > 0.55
          4 — stale enrichment (> 7 days or never enriched)

        Resets existing ranks for the brand first.
        Returns the number of matches ranked.
        """
        # Step 1: Reset all ranks for this brand
        self.db.execute(
            text(
                "UPDATE similarity_match"
                " SET enrichment_budget_rank = NULL"
                " WHERE brand_id = :brand_id"
            ),
            {"brand_id": brand_id},
        )

        # Step 2: Rank ALL immediate_attention matches first (no budget cap),
        # then fill remaining slots up to `limit` with lower-priority matches.
        self.db.execute(
            text("""
            WITH active AS (
                SELECT id, attention_bucket, first_detected_at,
                       score_final, actionability_score, last_enriched_at
                FROM similarity_match
                WHERE brand_id = :brand_id
                  AND (auto_disposition IS NULL OR auto_disposition = '')
                  AND (disposition IS NULL OR disposition NOT IN ('dismissed'))
            ),
            immediate AS (
                SELECT id,
                       ROW_NUMBER() OVER (
                           ORDER BY actionability_score DESC NULLS LAST, score_final DESC
                       ) AS r
                FROM active
                WHERE attention_bucket = 'immediate_attention'
            ),
            immediate_count AS (
                SELECT COUNT(*) AS n FROM immediate
            ),
            other AS (
                SELECT id,
                       ROW_NUMBER() OVER (
                           ORDER BY
                             CASE
                               WHEN first_detected_at::date = CURRENT_DATE THEN 1
                               WHEN attention_bucket = 'defensive_gap' THEN 2
                               WHEN attention_bucket = 'watchlist'
                                    AND score_final > 0.55 THEN 3
                               WHEN last_enriched_at IS NULL
                                    OR last_enriched_at < NOW() - INTERVAL '7 days' THEN 4
                               ELSE 5
                             END ASC,
                             actionability_score DESC NULLS LAST,
                             score_final DESC
                       ) AS r
                FROM active
                WHERE attention_bucket != 'immediate_attention'
            ),
            combined AS (
                SELECT id, r FROM immediate
                UNION ALL
                SELECT o.id, (ic.n + o.r)
                FROM other o, immediate_count ic
                WHERE o.r <= GREATEST(:limit - ic.n, 0)
            )
            UPDATE similarity_match sm
            SET enrichment_budget_rank = combined.r
            FROM combined WHERE sm.id = combined.id
            """),
            {"brand_id": brand_id, "limit": limit},
        )

        result = self.db.execute(
            text(
                "SELECT COUNT(*) FROM similarity_match"
                " WHERE brand_id = :brand_id AND enrichment_budget_rank IS NOT NULL"
            ),
            {"brand_id": brand_id},
        ).scalar()
        return int(result or 0)
